<?php
// Database credentials
$servername = "localhost";
$username = "root"; // Default XAMPP username
$password = "";     // Default XAMPP password
$dbname = "sms_db"; // The database name we created

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    // If the connection fails, show an error and stop execution
    die("Connection failed: " . $conn->connect_error);
}

// Optional: Set character set for proper data handling
$conn->set_charset("utf8");

// Note: We leave the connection open, as it will be used by other files
?>