<?php
// Include the database connection file
require 'config.php';

// FIX: Define $message at the start to prevent the 'Undefined variable' Warning
$message = ""; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 1. Get and sanitize input from the form
    // Use prepared statements for production code, but for this quick fix:
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $course = $conn->real_escape_string($_POST['course']);
    $admission_date = $conn->real_escape_string($_POST['admission_date']);
    
    // 2. SQL Query (INSERT)
    $sql = "INSERT INTO students (name, email, course, admission_date) 
            VALUES ('$name', '$email', '$course', '$admission_date')";

    // 3. Execute the query
    if ($conn->query($sql) === TRUE) {
        $message = "✅ New student added successfully!";
    } else {
        $message = "❌ Error: Could not add student. Email might already exist. " . $conn->error;
    }
}
// 4. Close the connection after operation
$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add New Student</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Add New Student (CREATE) 📝</h1>
        
        <div class="action-bar">
            <a href="dashboard.php" class="button back-button">← BACK TO DASHBOARD</a>
        </div>
        
        <?php 
        // Display the message using the enhanced CSS styles
        if (!empty($message)): 
        ?>
            <div class="message <?php echo strpos($message, '✅') !== false ? 'success' : 'error'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group"><BR>
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required placeholder="Enter student's full name">
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required placeholder="ABC.doe@university.com">
            </div>

            <div class="form-group">
                <label for="course">Course:</label>
                <input type="text" id="course" name="course" required placeholder="e.g., Computer Science, Business Admin">
            </div>

            <div class="form-group">
                <label for="admission_date">Admission Date:</label>
                <input type="date" id="admission_date" name="admission_date" required>
            </div>

            <button type="submit" class="button main-submit-button">ADD STUDENT</button>
        </form>
    </div>
</body>
</html>