<?php
// Include the database connection file
require 'config.php';

// 1. Fetch Summary Data (Total Students)
$summary_sql = "SELECT COUNT(id) AS total_students FROM students";
$summary_result = $conn->query($summary_sql);
$summary_data = $summary_result->fetch_assoc();
$total_students = $summary_data['total_students'];

// Note: Connection will be closed after view_students.php is included

?>
<!DOCTYPE html>
<html>
<head>
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Student Management Dashboard 📊</h1>
        
        <div class="summary-cards">
            <div class="card total-students">
                <h3>Total Students</h3>
                <p><?php echo $total_students; ?></p>
            </div>
            </div>
        <div class="action-bar">
            <a href="add_student.php" class="button">➕ ADD NEW STUDENT</a>
        </div>

        <?php include 'view_students.php'; ?>

    </div>
</body>
</html>
<?php
// Close the connection after operation
$conn->close();
?>