<?php
// Note: $conn is available from dashboard.php

// 1. SQL Query (SELECT all students with all columns)
$sql = "SELECT id, name, email, course, admission_date FROM students ORDER BY id DESC";

// 2. Execute the query
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h2>Registered Students:</h2>";
    echo "<div class='table-responsive'>"; // Add wrapper for responsiveness and height control
    echo "<table>";
    // Ensure all relevant fields are in the header
    echo "<thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Course</th><th>Admit Date</th></tr></thead>";
    echo "<tbody>";
    
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row["id"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["name"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["email"]) . "</td>"; // Displaying Email
        echo "<td>" . htmlspecialchars($row["course"]) . "</td>"; // Displaying Course
        echo "<td>" . htmlspecialchars($row["admission_date"]) . "</td>";
        echo "</tr>";
    }
    echo "</tbody>";
    echo "</table>";
    echo "</div>"; // Close table-responsive
} else {
    echo "<p class='no-records'>No students registered yet. Please add a student to begin.</p>";
}
?>