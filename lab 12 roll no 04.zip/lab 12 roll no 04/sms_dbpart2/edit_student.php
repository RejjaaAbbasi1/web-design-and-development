<?php
require 'config.php';

$message = "";
$student = []; 
$id_to_fetch = isset($_POST['update_id']) ? $_POST['update_id'] : (isset($_GET['id']) ? $_GET['id'] : null);

// --- PART 2: HANDLE UPDATE SUBMISSION ---
if (isset($_POST['update_id'])) {
    $id = $conn->real_escape_string($_POST['update_id']);
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $course = $conn->real_escape_string($_POST['course']);
    $admission_date = $conn->real_escape_string($_POST['admission_date']);

    $update_sql = "UPDATE students SET 
                   name = '$name', 
                   email = '$email', 
                   course = '$course', 
                   admission_date = '$admission_date' 
                   WHERE id = '$id'";

    if ($conn->query($update_sql) === TRUE) {
        $message = "✅ Student record updated successfully!";
    } else {
        $message = "❌ Error updating record: " . $conn->error;
    }
}

// --- PART 1: FETCH CURRENT DATA (or re-fetch after update) ---
if ($id_to_fetch) {
    $id = $conn->real_escape_string($id_to_fetch);
    $fetch_sql = "SELECT id, name, email, course, admission_date FROM students WHERE id = '$id'";
    $result = $conn->query($fetch_sql);

    if ($result->num_rows > 0) {
        $student = $result->fetch_assoc();
    } else {
        die("Student not found.");
    }
} else {
    die("Invalid access: No student ID provided.");
}

$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Student</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Edit Student (UPDATE) ✏️</h1>
        
        <div class="action-bar">
            <a href="dashboard.php" class="button back-button">← BACK TO DASHBOARD</a>
        </div>
        
        <?php if (!empty($message)): ?>
            <div class="message <?php echo strpos($message, '✅') !== false ? 'success' : 'error'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="edit_student.php">
            <input type="hidden" name="update_id" value="<?php echo htmlspecialchars($student['id']); ?>">

            <div class="form-group">
                <label for="id">Student ID:</label>
                <input type="text" id="id" value="<?php echo htmlspecialchars($student['id']); ?>" disabled>
            </div>
            
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($student['name']); ?>" required>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($student['email']); ?>" required>
            </div>

            <div class="form-group">
                <label for="course">Course:</label>
                <input type="text" id="course" name="course" value="<?php echo htmlspecialchars($student['course']); ?>" required>
            </div>

            <div class="form-group">
                <label for="admission_date">Admission Date:</label>
                <input type="date" id="admission_date" name="admission_date" value="<?php echo htmlspecialchars($student['admission_date']); ?>" required>
            </div>

            <button type="submit" class="button main-submit-button update-button">UPDATE RECORD</button>
        </form>
    </div>
</body>
</html>