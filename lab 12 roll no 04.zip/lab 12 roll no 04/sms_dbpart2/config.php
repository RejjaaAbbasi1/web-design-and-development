<?php
// Database credentials
$servername = "localhost";
$username = "root";     // Default XAMPP username
$password = "";         // Default XAMPP password
$dbname = "sms_db";     // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    // If connection fails, stop the application and display an error
    die("Connection failed: " . $conn->connect_error);
}

// Set character set for proper data handling
$conn->set_charset("utf8");
// Connection is left open to be used by other files
?>