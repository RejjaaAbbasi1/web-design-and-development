<?php
// Note: $conn is available from dashboard.php

// SQL Query (SELECT all students)
$sql = "SELECT id, name, email, course, admission_date FROM students ORDER BY id DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h2>Registered Students:</h2>";
    echo "<div class='table-responsive'>";
    echo "<table>";
    echo "<thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Course</th><th>Admit Date</th><th>Actions</th></tr></thead>";
    echo "<tbody>";
    
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row["id"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["name"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["email"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["course"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["admission_date"]) . "</td>";
        // Action Buttons for Edit and Delete
        echo "<td class='action-cell'>";
        echo "<a href='edit_student.php?id=" . $row["id"] . "' class='action-button edit-btn'>Edit</a>";
        echo "<a href='dashboard.php?delete_id=" . $row["id"] . "' class='action-button delete-btn' onclick=\"return confirm('Are you sure you want to permanently delete ' + '" . htmlspecialchars($row["name"]) . "?')\">Delete</a>";
        echo "</td>";
        echo "</tr>";
    }
    echo "</tbody>";
    echo "</table>";
    echo "</div>";
} else {
    echo "<p class='no-records'>No students registered yet. Please add a student to begin.</p>";
}
?>