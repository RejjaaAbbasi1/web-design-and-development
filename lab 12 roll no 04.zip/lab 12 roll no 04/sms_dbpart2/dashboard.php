<?php
require 'config.php';

$delete_message = "";

// --- HANDLE DELETE REQUEST ---
if (isset($_GET['delete_id'])) {
    $delete_id = $conn->real_escape_string($_GET['delete_id']);
    $delete_sql = "DELETE FROM students WHERE id = '$delete_id'";
    
    if ($conn->query($delete_sql) === TRUE) {
        $delete_message = "✅ Student ID $delete_id deleted successfully!";
    } else {
        $delete_message = "❌ Error deleting record: " . $conn->error;
    }
}

// Fetch Summary Data (Total Students)
$summary_sql = "SELECT COUNT(id) AS total_students FROM students";
$summary_result = $conn->query($summary_sql);
$summary_data = $summary_result->fetch_assoc();
$total_students = $summary_data['total_students'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Student Management Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Student Management Dashboard 📊</h1>
        
        <?php 
        // Display the delete message
        if (!empty($delete_message)): 
        ?>
            <div class="message <?php echo strpos($delete_message, '✅') !== false ? 'success' : 'error'; ?>">
                <?php echo $delete_message; ?>
            </div>
        <?php endif; ?>

        <div class="summary-cards">
            <div class="card total-students">
                <h3>Total Students</h3>
                <p><?php echo $total_students; ?></p>
            </div>
            <div class="card placeholder-card">
                <h3>Active Courses</h3>
                <p>N/A</p>
            </div>
            <div class="card placeholder-card">
                <h3>Latest Admission</h3>
                <p>N/A</p>
            </div>
        </div>
        
        <div class="action-bar">
            <a href="add_student.php" class="button">➕ ADD NEW STUDENT</a>
        </div>

        <?php include 'view_students.php'; ?>

    </div>
</body>
</html>
<?php
// Close the database connection
$conn->close();
?>