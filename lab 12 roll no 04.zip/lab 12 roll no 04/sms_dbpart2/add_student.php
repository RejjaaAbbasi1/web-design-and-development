<?php
require 'config.php';

// FIX: Define $message at the start to prevent the 'Undefined variable' Warning
$message = ""; // This line resolves the warning.

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Input sanitization and validation (basic)
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $course = $conn->real_escape_string($_POST['course']);
    $admission_date = $conn->real_escape_string($_POST['admission_date']);
    
    // SQL Query
    $sql = "INSERT INTO students (name, email, course, admission_date) 
            VALUES ('$name', '$email', '$course', '$admission_date')";

    if ($conn->query($sql) === TRUE) {
        $message = "✅ New student added successfully!";
    } else {
        $message = "❌ Error: Could not add student. Email might already exist. " . $conn->error;
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add New Student</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Add New Student (CREATE) 📝</h1>
        
        <div class="action-bar">
            <a href="dashboard.php" class="button back-button">← BACK TO DASHBOARD</a>
        </div>
        
        <?php 
        if (!empty($message)): 
        ?>
            <div class="message <?php echo strpos($message, '✅') !== false ? 'success' : 'error'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required placeholder="Enter student's full name">
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required placeholder="e.g., john.doe@university.com">
            </div>

            <div class="form-group">
                <label for="course">Course:</label>
                <input type="text" id="course" name="course" required placeholder="e.g., Computer Science, Business Admin">
            </div>

            <div class="form-group">
                <label for="admission_date">Admission Date:</label>
                <input type="date" id="admission_date" name="admission_date" required>
            </div>

            <button type="submit" class="button main-submit-button update-button">ADD STUDENT</button>
        </form>
    </div>
</body>
</html>